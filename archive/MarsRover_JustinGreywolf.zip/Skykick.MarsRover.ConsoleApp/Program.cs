﻿namespace Skykick.MarsRover.ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var roverApp = new RoverApplication();
            roverApp.Run();
        }
    }
}
